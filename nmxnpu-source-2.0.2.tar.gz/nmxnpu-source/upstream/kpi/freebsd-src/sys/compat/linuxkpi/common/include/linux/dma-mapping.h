/*-
 * Copyright (c) 2010 Isilon Systems, Inc.
 * Copyright (c) 2010 iX Systems, Inc.
 * Copyright (c) 2010 Panasas, Inc.
 * Copyright (c) 2013, 2014 Mellanox Technologies, Ltd.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice unmodified, this list of conditions, and the following
 *    disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef	_LINUXKPI_LINUX_DMA_MAPPING_H_
#define _LINUXKPI_LINUX_DMA_MAPPING_H_

#include <linux/types.h>
#include <linux/device.h>
#include <linux/err.h>
#include <linux/scatterlist.h>
#include <linux/mm.h>
#include <linux/page.h>
#include <linux/sizes.h>

#include <sys/systm.h>
#include <sys/malloc.h>

#include <vm/vm.h>
#include <vm/vm_page.h>
#include <vm/uma_align_mask.h>
#include <vm/pmap.h>

#include <machine/bus.h>

#define	DMA_ATTR_WRITE_BARRIER		(1 << 0)
#define	DMA_ATTR_WEAK_ORDERING		(1 << 1)
#define	DMA_ATTR_WRITE_COMBINE		(1 << 2)
#define	DMA_ATTR_NON_CONSISTENT		(1 << 3)
#define	DMA_ATTR_NO_KERNEL_MAPPING	(1 << 4)
#define	DMA_ATTR_SKIP_CPU_SYNC		(1 << 5)
#define	DMA_ATTR_FORCE_CONTIGUOUS	(1 << 6)
#define	DMA_ATTR_ALLOC_SINGLE_PAGES	(1 << 7)
#define	DMA_ATTR_NO_WARN		(1 << 8)
#define	DMA_ATTR_PRIVILEGED		(1 << 9)

enum dma_data_direction {
	DMA_BIDIRECTIONAL = 0,
	DMA_TO_DEVICE = 1,
	DMA_FROM_DEVICE = 2,
	DMA_NONE = 3,
};

struct dma_map_ops {
	void* (*alloc_coherent)(struct device *dev, size_t size,
	    dma_addr_t *dma_handle, gfp_t gfp);
	void (*free_coherent)(struct device *dev, size_t size,
	    void *vaddr, dma_addr_t dma_handle);
	dma_addr_t (*map_page)(struct device *dev, struct page *page,
	    unsigned long offset, size_t size, enum dma_data_direction dir,
	    unsigned long attrs);
	void (*unmap_page)(struct device *dev, dma_addr_t dma_handle,
	    size_t size, enum dma_data_direction dir, unsigned long attrs);
	int (*map_sg)(struct device *dev, struct scatterlist *sg,
	    int nents, enum dma_data_direction dir, unsigned long attrs);
	void (*unmap_sg)(struct device *dev, struct scatterlist *sg, int nents,
	    enum dma_data_direction dir, unsigned long attrs);
	void (*sync_single_for_cpu)(struct device *dev, dma_addr_t dma_handle,
	    size_t size, enum dma_data_direction dir);
	void (*sync_single_for_device)(struct device *dev,
	    dma_addr_t dma_handle, size_t size, enum dma_data_direction dir);
	void (*sync_single_range_for_cpu)(struct device *dev,
	    dma_addr_t dma_handle, unsigned long offset, size_t size,
	    enum dma_data_direction dir);
	void (*sync_single_range_for_device)(struct device *dev,
	    dma_addr_t dma_handle, unsigned long offset, size_t size,
	    enum dma_data_direction dir);
	void (*sync_sg_for_cpu)(struct device *dev, struct scatterlist *sg,
	    int nents, enum dma_data_direction dir);
	void (*sync_sg_for_device)(struct device *dev, struct scatterlist *sg,
	    int nents, enum dma_data_direction dir);
	int (*mapping_error)(struct device *dev, dma_addr_t dma_addr);
	int (*dma_supported)(struct device *dev, u64 mask);
	int is_phys;
};

#define	DMA_BIT_MASK(n)	((2ULL << ((n) - 1)) - 1ULL)

int linux_dma_tag_init(struct device *, u64);
int linux_dma_tag_init_coherent(struct device *, u64);
void *linux_dma_alloc_coherent(struct device *dev, size_t size,
    dma_addr_t *dma_handle, gfp_t flag);
void *linuxkpi_dmam_alloc_coherent(struct device *dev, size_t size,
    dma_addr_t *dma_handle, gfp_t flag);
void linuxkpi_dmam_free_coherent(struct device *dev, size_t size,
    void *addr, dma_addr_t dma_handle);
void *linuxkpi_dma_alloc_noncoherent(struct device *, size_t, dma_addr_t *,
    enum dma_data_direction, gfp_t);
void linuxkpi_dma_free_noncoherent(struct device *, size_t, void *,
    dma_addr_t, enum dma_data_direction);
void *linuxkpi_dma_alloc_attrs(struct device *, size_t, dma_addr_t *,
    gfp_t, unsigned long);
void linuxkpi_dma_free_attrs(struct device *, size_t, void *,
    dma_addr_t, unsigned long);
dma_addr_t linux_dma_map_phys(struct device *dev, vm_paddr_t phys, size_t len);	/* backward compat */
dma_addr_t lkpi_dma_map_phys(struct device *, vm_paddr_t, size_t,
    enum dma_data_direction, unsigned long);
void linux_dma_unmap(struct device *dev, dma_addr_t dma_addr, size_t size);	/* backward compat */
void lkpi_dma_unmap(struct device *, dma_addr_t, size_t,
    enum dma_data_direction, unsigned long);
int linux_dma_map_sg_attrs(struct device *dev, struct scatterlist *sgl,
    int nents, enum dma_data_direction direction,
    unsigned long attrs);
void linux_dma_unmap_sg_attrs(struct device *dev, struct scatterlist *sg,
    int nents __unused, enum dma_data_direction direction,
    unsigned long attrs);
void linuxkpi_dma_sync(struct device *, dma_addr_t, size_t, bus_dmasync_op_t);
void lkpi_dma_sync_sg(struct device *, struct scatterlist *, bus_dmasync_op_t);

static inline int
dma_supported(struct device *dev, u64 dma_mask)
{

	/* XXX busdma takes care of this elsewhere. */
	return (1);
}

static inline int
dma_set_mask(struct device *dev, u64 dma_mask)
{

	if (!dev->dma_priv || !dma_supported(dev, dma_mask))
		return -EIO;

	return (linux_dma_tag_init(dev, dma_mask));
}

static inline int
dma_set_coherent_mask(struct device *dev, u64 dma_mask)
{

	if (!dev->dma_priv || !dma_supported(dev, dma_mask))
		return -EIO;

	return (linux_dma_tag_init_coherent(dev, dma_mask));
}

static inline int
dma_set_mask_and_coherent(struct device *dev, u64 dma_mask)
{
	int r;

	r = dma_set_mask(dev, dma_mask);
	if (r == 0)
		dma_set_coherent_mask(dev, dma_mask);
	return (r);
}

static inline void *
dma_alloc_coherent(struct device *dev, size_t size, dma_addr_t *dma_handle,
    gfp_t flag)
{
	return (linux_dma_alloc_coherent(dev, size, dma_handle, flag));
}

static inline void *
dma_zalloc_coherent(struct device *dev, size_t size, dma_addr_t *dma_handle,
    gfp_t flag)
{

	return (dma_alloc_coherent(dev, size, dma_handle, flag | __GFP_ZERO));
}

static inline void *
dmam_alloc_coherent(struct device *dev, size_t size, dma_addr_t *dma_handle,
    gfp_t flag)
{

	return (linuxkpi_dmam_alloc_coherent(dev, size, dma_handle, flag));
}

static inline void
dma_free_coherent(struct device *dev, size_t size, void *cpu_addr,
    dma_addr_t dma_addr)
{

	lkpi_dma_unmap(dev, dma_addr, size, DMA_BIDIRECTIONAL, 0);
	kmem_free(cpu_addr, size);
}

static inline void
dmam_free_coherent(struct device *dev, size_t size, void *addr,
    dma_addr_t dma_handle)
{
	linuxkpi_dmam_free_coherent(dev, size, addr, dma_handle);
}

static inline void *
dma_alloc_noncoherent(struct device *dev, size_t size, dma_addr_t *dma_handle,
    enum dma_data_direction direction, gfp_t gfp)
{
	return (linuxkpi_dma_alloc_noncoherent(dev, size, dma_handle, direction, gfp));
}

static inline void
dma_free_noncoherent(struct device *dev, size_t size, void *vaddr,
    dma_addr_t dma_handle, enum dma_data_direction direction)
{
	linuxkpi_dma_free_noncoherent(dev, size, vaddr, dma_handle, direction);
}

static inline void *
dma_alloc_attrs(struct device *dev, size_t size, dma_addr_t *dma_handle,
    gfp_t gfp, unsigned long attrs)
{
	return (linuxkpi_dma_alloc_attrs(dev, size, dma_handle, gfp, attrs));
}

static inline void
dma_free_attrs(struct device *dev, size_t size, void *vaddr,
    dma_addr_t dma_handle, unsigned long attrs)
{
	linuxkpi_dma_free_attrs(dev, size, vaddr, dma_handle, attrs);
}

static inline dma_addr_t
dma_map_page_attrs(struct device *dev, struct page *page, size_t offset,
    size_t size, enum dma_data_direction direction, unsigned long attrs)
{

	return (lkpi_dma_map_phys(dev, page_to_phys(page) + offset, size,
	    direction, attrs));
}

static inline void
dma_unmap_page_attrs(struct device *dev, dma_addr_t dma_address, size_t size,
    enum dma_data_direction direction, unsigned long attrs)
{
       lkpi_dma_unmap(dev, dma_address, size, direction, attrs);
}

/* linux_dma_(un)map_sg_attrs does not support attrs yet */
#define	dma_map_sg_attrs(dev, sgl, nents, dir, attrs)	\
	linux_dma_map_sg_attrs(dev, sgl, nents, dir, attrs)

#define	dma_unmap_sg_attrs(dev, sg, nents, dir, attrs)	\
	linux_dma_unmap_sg_attrs(dev, sg, nents, dir, attrs)

static inline dma_addr_t
dma_map_page(struct device *dev, struct page *page,
    unsigned long offset, size_t size, enum dma_data_direction direction)
{

	return (lkpi_dma_map_phys(dev, page_to_phys(page) + offset, size,
	    direction, 0));
}

static inline void
dma_unmap_page(struct device *dev, dma_addr_t dma_address, size_t size,
    enum dma_data_direction direction)
{

	lkpi_dma_unmap(dev, dma_address, size, direction, 0);
}

static inline dma_addr_t
dma_map_resource(struct device *dev, phys_addr_t paddr, size_t size,
    enum dma_data_direction direction, unsigned long attrs)
{
	return (lkpi_dma_map_phys(dev, paddr, size, direction, attrs));
}

static inline void
dma_unmap_resource(struct device *dev, dma_addr_t dma, size_t size,
    enum dma_data_direction direction, unsigned long attrs)
{
	lkpi_dma_unmap(dev, dma, size, direction, attrs);
}

static inline void
dma_sync_single_for_cpu(struct device *dev, dma_addr_t dma, size_t size,
    enum dma_data_direction direction)
{
	bus_dmasync_op_t op;

	switch (direction) {
	case DMA_BIDIRECTIONAL:
		op = BUS_DMASYNC_POSTREAD | BUS_DMASYNC_POSTWRITE;
		break;
	case DMA_TO_DEVICE:
		op = BUS_DMASYNC_POSTWRITE;
		break;
	case DMA_FROM_DEVICE:
		op = BUS_DMASYNC_POSTREAD;
		break;
	default:
		return;
	}

	linuxkpi_dma_sync(dev, dma, size, op);
}

static inline void
dma_sync_single(struct device *dev, dma_addr_t addr, size_t size,
    enum dma_data_direction dir)
{
	dma_sync_single_for_cpu(dev, addr, size, dir);
}

static inline void
dma_sync_single_for_device(struct device *dev, dma_addr_t dma,
    size_t size, enum dma_data_direction direction)
{
	bus_dmasync_op_t op;

	switch (direction) {
	case DMA_BIDIRECTIONAL:
		op = BUS_DMASYNC_PREWRITE | BUS_DMASYNC_PREREAD;
		break;
	case DMA_TO_DEVICE:
		op = BUS_DMASYNC_PREWRITE;
		break;
	case DMA_FROM_DEVICE:
		op = BUS_DMASYNC_PREREAD;
		break;
	default:
		return;
	}

	linuxkpi_dma_sync(dev, dma, size, op);
}

static inline void
dma_sync_sg_for_cpu(struct device *dev, struct scatterlist *sg, int nelems,
    enum dma_data_direction direction)
{
	bus_dmasync_op_t op;

	switch (direction) {
	case DMA_BIDIRECTIONAL:
		op = BUS_DMASYNC_POSTREAD | BUS_DMASYNC_POSTWRITE;
		break;
	case DMA_TO_DEVICE:
		op = BUS_DMASYNC_POSTWRITE;
		break;
	case DMA_FROM_DEVICE:
		op = BUS_DMASYNC_POSTREAD;
		break;
	default:
		return;
	}

	lkpi_dma_sync_sg(dev, sg, op);
}

static inline void dma_sync_sgtable_for_cpu(struct device *dev,
		struct sg_table *sgt, enum dma_data_direction dir)
{
	dma_sync_sg_for_cpu(dev, sgt->sgl, sgt->orig_nents, dir);
}

static inline void
dma_sync_sg_for_device(struct device *dev, struct scatterlist *sg, int nelems,
    enum dma_data_direction direction)
{
	bus_dmasync_op_t op;

	switch (direction) {
	case DMA_BIDIRECTIONAL:
		op = BUS_DMASYNC_PREWRITE | BUS_DMASYNC_PREREAD;
		break;
	case DMA_TO_DEVICE:
		op = BUS_DMASYNC_PREWRITE;
		break;
	case DMA_FROM_DEVICE:
		op = BUS_DMASYNC_PREREAD;
		break;
	default:
		return;
	}

	lkpi_dma_sync_sg(dev, sg, op);
}

static inline void dma_sync_sgtable_for_device(struct device *dev,
		struct sg_table *sgt, enum dma_data_direction dir)
{
	dma_sync_sg_for_device(dev, sgt->sgl, sgt->orig_nents, dir);
}

/* (20250329) These two seem to be unused code. */
static inline void
dma_sync_single_range_for_cpu(struct device *dev, dma_addr_t dma_handle,
    unsigned long offset, size_t size, enum dma_data_direction direction)
{
	pr_debug("%s:%d: TODO dir %d\n", __func__, __LINE__, direction);
}

static inline void
dma_sync_single_range_for_device(struct device *dev, dma_addr_t dma_handle,
    unsigned long offset, size_t size, enum dma_data_direction direction)
{
	pr_debug("%s:%d: TODO dir %d\n", __func__, __LINE__, direction);
}

#define	DMA_MAPPING_ERROR	(~(dma_addr_t)0)

static inline int
dma_mapping_error(struct device *dev, dma_addr_t dma_addr)
{

	if (dma_addr == 0 || dma_addr == DMA_MAPPING_ERROR)
		return (-ENOMEM);
	return (0);
}

static inline unsigned int dma_set_max_seg_size(struct device *dev,
    unsigned int size)
{
	return (0);
}

static inline dma_addr_t
_dma_map_single_attrs(struct device *dev, void *ptr, size_t size,
    enum dma_data_direction direction, unsigned long attrs)
{
	return (lkpi_dma_map_phys(dev, vtophys(ptr), size,
	    direction, attrs));
}

static inline void
_dma_unmap_single_attrs(struct device *dev, dma_addr_t dma, size_t size,
    enum dma_data_direction direction, unsigned long attrs)
{
	lkpi_dma_unmap(dev, dma, size, direction, attrs);
}

static inline size_t
dma_max_mapping_size(struct device *dev)
{

	return (SCATTERLIST_MAX_SEGMENT);
}

#define	dma_map_single_attrs(dev, ptr, size, dir, attrs)	\
	_dma_map_single_attrs(dev, ptr, size, dir, attrs)

#define	dma_unmap_single_attrs(dev, dma_addr, size, dir, attrs)	\
	_dma_unmap_single_attrs(dev, dma_addr, size, dir, attrs)

#define dma_map_single(d, a, s, r) dma_map_single_attrs(d, a, s, r, 0)
#define dma_unmap_single(d, a, s, r) dma_unmap_single_attrs(d, a, s, r, 0)
#define dma_map_sg(d, s, n, r) dma_map_sg_attrs(d, s, n, r, 0)
#define dma_unmap_sg(d, s, n, r) dma_unmap_sg_attrs(d, s, n, r, 0)

#define	DEFINE_DMA_UNMAP_ADDR(name)		dma_addr_t name
#define	DEFINE_DMA_UNMAP_LEN(name)		__u32 name
#define	dma_unmap_addr(p, name)			((p)->name)
#define	dma_unmap_addr_set(p, name, v)		(((p)->name) = (v))
#define	dma_unmap_len(p, name)			((p)->name)
#define	dma_unmap_len_set(p, name, v)		(((p)->name) = (v))

#define	dma_get_cache_alignment()	(uma_get_cache_align_mask() + 1)


static inline int
dma_map_sgtable(struct device *dev, struct sg_table *sgt,
    enum dma_data_direction dir,
    unsigned long attrs)
{
	int nents;

	nents = dma_map_sg_attrs(dev, sgt->sgl, sgt->orig_nents, dir, attrs);
	if (nents < 0)
		return (nents);
	sgt->nents = nents;
	return (0);
}

static inline void
dma_unmap_sgtable(struct device *dev, struct sg_table *sgt,
    enum dma_data_direction dir,
    unsigned long attrs)
{

	dma_unmap_sg_attrs(dev, sgt->sgl, sgt->orig_nents, dir, attrs);
}


#endif	/* _LINUXKPI_LINUX_DMA_MAPPING_H_ */
